﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Toolbox.Core.ViewModels
{
    public class NodePropertyUI
    {
        public EventHandler UIDrawer;
    }
}
